function solve() {
   // TODO: Add the functionality here.
}

solve();